(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };

  /* ================= Kirish animatsiyasi ================= */
  var splash = $("splash"), left = false;

  // "CSV Jadval" harflarini bittadan animatsiya qilish uchun bo'lamiz
  var title = $("sTitle"), text = title.getAttribute("aria-label");
  title.textContent = "";
  text.split("").forEach(function (ch, i) {
    var s = document.createElement("span");
    s.textContent = ch === " " ? "\u00a0" : ch;
    s.style.setProperty("--i", i);
    title.appendChild(s);
  });

  // CSV namunadagi vergullarni rangli qilish
  document.querySelectorAll("#sCsv .l span").forEach(function (el) {
    el.innerHTML = el.textContent.replace(/,/g, '<span class="c">,</span>');
  });

  function leave() {
    if (left) return;
    left = true;
    splash.classList.add("leave");          // tepaga uchib ketadi
    document.body.classList.add("ready");   // sahifa paydo bo'ladi
    setTimeout(function () {
      splash.remove();
      document.body.classList.remove("locked");
    }, 1000);
  }
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce) { splash.remove(); document.body.classList.remove("locked"); document.body.classList.add("ready"); left = true; }
  else {
    setTimeout(leave, 5000);                // o'zi uchib ketadi
    $("sSkip").onclick = leave;
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" || e.key === "Enter") leave(); });
  }

  /* ================= CSV jadval ================= */
  var csvEl = $("csv"), tbl = $("tbl"), q = $("q"), sortCol = $("sortCol"), sortDir = $("sortDir"),
      err = $("err"), stats = $("stats");
  var header = [], rows = [], numeric = [], nameCol = 0, scoreCol = -1, rankMap = new Map();
  var SAMPLE = csvEl.value;

  // CSV matnini qatorlar va ustunlarga ajratadi ("qo'shtirnoq" ichidagi vergul ham ishlaydi)
  function parse(text) {
    text = text.replace(/\r\n?/g, "\n").replace(/^\uFEFF/, "");
    var first = text.split("\n")[0] || "", d = ",";
    if (first.indexOf(",") < 0) { if (first.indexOf(";") >= 0) d = ";"; else if (first.indexOf("\t") >= 0) d = "\t"; }
    var out = [], row = [], cell = "", inQ = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (inQ) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else inQ = false; }
        else cell += c;
      } else if (c === '"') inQ = true;
      else if (c === d) { row.push(cell.trim()); cell = ""; }
      else if (c === "\n") { row.push(cell.trim()); out.push(row); row = []; cell = ""; }
      else cell += c;
    }
    row.push(cell.trim()); out.push(row);
    return out.filter(function (r) { return r.some(function (x) { return x !== ""; }); });
  }

  function toNum(s) {
    if (s == null || s === "") return NaN;
    var t = String(s).replace(/\s/g, "").replace(",", ".");
    return /^[-+]?\d*\.?\d+(e[-+]?\d+)?$/i.test(t) ? parseFloat(t) : NaN;
  }

  function load() {
    err.textContent = "";
    var data = parse(csvEl.value);
    if (data.length < 1) { header = []; rows = []; numeric = []; scoreCol = -1; fillSort(); render(); return; }
    header = data[0].map(function (h, i) { return h || ("Ustun " + (i + 1)); });
    var n = header.length, bad = 0;
    rows = data.slice(1).map(function (r) {
      if (r.length !== n) bad++;
      var o = r.slice(0, n); while (o.length < n) o.push(""); return o;
    });
    numeric = header.map(function (_, i) {
      var v = rows.map(function (r) { return r[i]; }).filter(function (x) { return x !== ""; });
      return v.length > 0 && v.every(function (x) { return !isNaN(toNum(x)); });
    });
    var ni = header.findIndex(function (h) { return /^(nom|name|ism)$/i.test(h); });
    nameCol = ni >= 0 ? ni : 0;
    scoreCol = numeric.indexOf(true);

    // O'rinlar: eng katta son 1-o'rin, teng sonlar bir xil o'rin oladi
    rankMap = new Map();
    if (scoreCol >= 0) {
      rows.forEach(function (r) {
        var s = toNum(r[scoreCol]);
        if (isNaN(s)) return;
        var better = rows.filter(function (o) { var t = toNum(o[scoreCol]); return !isNaN(t) && t > s; }).length;
        rankMap.set(r, better + 1);
      });
    }
    if (bad) err.textContent = bad + " ta satrda ustunlar soni sarlavhadan farq qiladi, bo'sh joylar to'ldirildi.";
    fillSort(); render();
  }

  function fillSort() {
    var prev = sortCol.value;
    sortCol.innerHTML = "";
    var none = document.createElement("option"); none.value = "-1"; none.textContent = "Saralanmagan"; sortCol.appendChild(none);
    header.forEach(function (h, i) {
      var o = document.createElement("option"); o.value = i; o.textContent = h + (numeric[i] ? " (son)" : ""); sortCol.appendChild(o);
    });
    if (prev !== "" && prev !== "-1" && +prev < header.length) sortCol.value = prev;
    else { sortCol.value = scoreCol >= 0 ? String(scoreCol) : "-1"; if (scoreCol >= 0) sortDir.value = "desc"; }
  }

  // Qidiruvda topilgan harflarni sariq qiladi
  function highlight(td, text, term) {
    td.textContent = "";
    if (!term) { td.textContent = text; return; }
    var low = text.toLowerCase(), t = term.toLowerCase(), i = 0, j;
    while ((j = low.indexOf(t, i)) >= 0) {
      td.appendChild(document.createTextNode(text.slice(i, j)));
      var m = document.createElement("mark"); m.textContent = text.slice(j, j + t.length); td.appendChild(m);
      i = j + t.length;
    }
    td.appendChild(document.createTextNode(text.slice(i)));
  }

  function render() {
    tbl.innerHTML = ""; stats.innerHTML = "";
    if (!header.length) { tbl.innerHTML = '<tbody><tr><td class="empty">CSV matnini yuqoridagi maydonga yozing.</td></tr></tbody>'; return; }
    var term = q.value.trim(), col = +sortCol.value, dir = sortDir.value === "desc" ? -1 : 1, hasRank = scoreCol >= 0;

    // 1) nom bo'yicha qidiruv
    var list = rows.filter(function (r) { return !term || r[nameCol].toLowerCase().indexOf(term.toLowerCase()) >= 0; });

    // 2) tanlangan ustun bo'yicha saralash (son ustuni son sifatida)
    if (col >= 0) {
      var isN = numeric[col];
      list = list.slice().sort(function (a, b) {
        var x = a[col], y = b[col];
        if (isN) {
          var nx = toNum(x), ny = toNum(y);
          if (isNaN(nx) && isNaN(ny)) return 0;
          if (isNaN(nx)) return 1; if (isNaN(ny)) return -1;
          return (nx - ny) * dir;
        }
        return x.localeCompare(y, "uz", { sensitivity: "base", numeric: true }) * dir;
      });
    }

    // sarlavha
    var thead = document.createElement("thead"), tr = document.createElement("tr");
    if (hasRank) { var rk = document.createElement("th"); rk.className = "rk"; rk.textContent = "O'rin"; tr.appendChild(rk); }
    header.forEach(function (h, i) {
      var th = document.createElement("th"); if (i === col) th.className = "sorted";
      th.setAttribute("aria-sort", i === col ? (dir === 1 ? "ascending" : "descending") : "none");
      var b = document.createElement("button"); b.type = "button"; b.title = "Shu ustun bo'yicha saralash";
      var s = document.createElement("span"); s.textContent = h;
      var a = document.createElement("span"); a.className = "arrow"; a.textContent = i === col ? (dir === 1 ? "▲" : "▼") : "";
      b.appendChild(s); b.appendChild(a);
      b.onclick = function () {
        if (+sortCol.value === i) sortDir.value = sortDir.value === "asc" ? "desc" : "asc";
        else { sortCol.value = String(i); sortDir.value = numeric[i] ? "desc" : "asc"; }
        render();
      };
      th.appendChild(b); tr.appendChild(th);
    });
    thead.appendChild(tr); tbl.appendChild(thead);

    // qatorlar
    var tb = document.createElement("tbody");
    if (!list.length) {
      var r0 = document.createElement("tr"), c0 = document.createElement("td");
      c0.colSpan = header.length + (hasRank ? 1 : 0); c0.className = "empty";
      c0.textContent = '"' + term + '" bo\'yicha hech kim topilmadi.';
      r0.appendChild(c0); tb.appendChild(r0);
    }
    list.forEach(function (r) {
      var tr = document.createElement("tr");
      if (hasRank) {
        var td = document.createElement("td"), rank = rankMap.get(r), m = document.createElement("span");
        m.className = "medal" + (rank && rank <= 3 ? " r" + rank : ""); m.textContent = rank || "–";
        td.appendChild(m); tr.appendChild(td);
      }
      r.forEach(function (v, i) {
        var td = document.createElement("td");
        if (numeric[i]) td.className = "num";
        if (i === col) td.className += " sorted";
        if (i === nameCol) highlight(td, v, term); else td.textContent = v;
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    tbl.appendChild(tb);

    // statistika
    var s = '<span><b>' + list.length + '</b> / ' + rows.length + ' ta qator</span>';
    if (scoreCol >= 0) {
      var sum = list.reduce(function (a, r) { var n = toNum(r[scoreCol]); return a + (isNaN(n) ? 0 : n); }, 0);
      s += '<span>' + header[scoreCol].replace(/</g, "&lt;") + " yig'indisi: <b>" + (Math.round(sum * 100) / 100).toLocaleString("ru-RU") + "</b></span>";
    }
    stats.innerHTML = s;
  }

  /* ================= Tugmalar ================= */
  $("go").onclick = load;
  csvEl.addEventListener("input", load);
  q.addEventListener("input", render);
  sortCol.addEventListener("change", render);
  sortDir.addEventListener("change", render);
  $("sample").onclick = function () { csvEl.value = SAMPLE; q.value = ""; load(); };
  $("clear").onclick = function () { csvEl.value = ""; q.value = ""; load(); csvEl.focus(); };
  $("fileBtn").onclick = function () { $("file").click(); };
  $("file").onchange = function (e) {
    var f = e.target.files[0]; if (!f) return;
    var rd = new FileReader(); rd.onload = function () { csvEl.value = rd.result; load(); }; rd.readAsText(f);
  };
  $("theme").onclick = function () {
    var root = document.documentElement, cur = root.getAttribute("data-theme");
    var dark = cur === "dark" || (!cur && matchMedia("(prefers-color-scheme: dark)").matches);
    root.setAttribute("data-theme", dark ? "light" : "dark");
  };

  load();
})();
